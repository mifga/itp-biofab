tiny birdhouse ornament by lucasmatic on Thingiverse: https://www.thingiverse.com/thing:5149279

Summary:
Tiny birdhouse ornaments for tiny trees.Remixed from Wingspan, Na skrzydłach. Bird house action selection marker.